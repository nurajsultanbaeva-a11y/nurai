class Book {
  String _title;
  String _author;
  double _rating = 0.0;

  // Обычный конструктор
  Book(this._title, this._author);

  // Именованный конструктор
  Book.withRating(this._title, this._author, double rating) {
    this.rating = rating;
  }

  // Геттеры
  String get title => _title;
  String get author => _author;
  double get rating => _rating;

  // Сеттер с проверкой
  set rating(double value) {
    if (value >= 0 && value <= 10) {
      _rating = value;
    } else {
      print('Ошибка: рейтинг должен быть от 0 до 10');
    }
  }

  // Вывод информации
  void displayInfo() {
    print('Title: $_title');
    print('Author: $_author');
    print('Rating: $_rating');
  }
}

class Library {
  String name;
  List<Book> _books = [];

  // Конструктор
  Library(this.name);

  // Добавление книги
  void addBook(Book b) {
    _books.add(b);
  }

  // Вывод списка книг
  void showBooks() {
    print('Library: $name');
    print('Books list:');

    for (int i = 0; i < _books.length; i++) {
      print('${i + 1}. ${_books[i].title}');
    }
  }

  int get totalBooks => _books.length;
}

void main() {
  // 1. Обычный конструктор
  Book book1 = Book('Harry Potter', 'J.K. Rowling');

  // 2. Именованный конструктор
  Book book2 = Book.withRating(
      'Sherlock Holmes', 'Arthur Conan Doyle', 9.2);

  // 3. Через сеттер
  Book book3 = Book('The Hobbit', 'J.R.R. Tolkien');
  book3.rating = 8.7;

  // Библиотека
  Library cityLib = Library('City Library');

  // Добавление книг
  cityLib.addBook(book1);
  cityLib.addBook(book2);
  cityLib.addBook(book3);

  // Вывод
  cityLib.showBooks();

  print('Total books in library: ${cityLib.totalBooks}');
}